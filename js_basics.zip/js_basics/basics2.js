const flag = true;


console.log(flag);
console.log(!flag);

//flag = false It can't be done because variable is a CONST.


for (let k=0;k<=10;k++){
    console.log(k)
}