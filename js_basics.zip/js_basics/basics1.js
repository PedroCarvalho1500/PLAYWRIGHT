console.log("Hello World");

//these are comments

/*
Comments on more than one line ...
... as you can see.
*/

let a=4;
console.log(a);
console.log(typeof(a));
//var (let,const) ES6 var

let b = 234.6;
console.log(typeof(b));

let c = "Peter";
console.log(typeof(c));

let required = true;
console.log(typeof(required));

let sum = a+b
console.log(sum)

c = a - b
console.log(c)
//we cannot redeclare variable with let keyword but it's possible with var

console.log(!required)

//null and undefined